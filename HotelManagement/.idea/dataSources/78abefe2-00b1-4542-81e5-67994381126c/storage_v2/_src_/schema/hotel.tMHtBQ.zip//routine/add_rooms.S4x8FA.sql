create
    definer = root@localhost procedure add_rooms()
BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE j INT DEFAULT 1;
  WHILE i <= 50 DO
    SET j = 1;
    WHILE j <= 10 DO
      INSERT INTO rooms (room_number, room_category, is_occupied, hotel_id)
      VALUES (CONCAT(i, '0', j), IF(j % 2 = 0, 'Double', 'Single'), 0, i);
      SET j = j + 1;
    END WHILE;
    SET i = i + 1;
  END WHILE;
END;

